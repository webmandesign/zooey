# Zooey Changelog

## 1.0.0, 20240415

- Initial release.

### Updated

Starter theme prefix placeholders were replaced with these values:

| Placeholder  | Replacement  |
|--------------|--------------|
| `Themename`  | Zooey        |
| `theme-slug` | zooey        |
| `theme_slug` | zooey        |
| `THEME_SLUG` | ZOOEY        |
| `Theme_Slug` | Zooey        |
| `themeSlug`  | zooey        |
| `__1.0.0`    | 1.0.0        |
